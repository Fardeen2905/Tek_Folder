package com.testng.project;

import org.testng.annotations.Test;

public class FirstTestngTest {
	
	@Test
	public void testHelloWorld(){
		System.out.println("Hello World");	
		}

}
