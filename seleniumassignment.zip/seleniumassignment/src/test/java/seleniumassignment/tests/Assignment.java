package seleniumassignment.tests;



import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import seleniumassignment.TestComponents.BaseTest;
import seleniumassignment.pageobjects.CartPage;
import seleniumassignment.pageobjects.CheckoutPage;
import seleniumassignment.pageobjects.ConfirmationPage;
import seleniumassignment.pageobjects.LandingPage;
import seleniumassignment.pageobjects.ProductCatalogue;

public class Assignment extends BaseTest{

	   @Test
		
		public void assignment() throws IOException, InterruptedException
		{
		
		   
			String filePath = "C:\\Users\\fmahammad\\Downloads\\demo.txt";

			try {
				BufferedReader reader = new BufferedReader(new FileReader(filePath));
				String url;

				while ((url = reader.readLine()) != null) {

					driver.get(url);

				}

				reader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
	
		

		String productName = "ZARA COAT 3";
		
//		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
//		
//		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
//		
//		LandingPage landingPage = new LandingPage(driver);
		
		LandingPage landingPage = launchApplication();
		
		
		
		ProductCatalogue productCatalogue = landingPage.loginApplication("mahammadfardeenbaig@gmail.com", "Fardeen@2905");
		

		
		
		List<WebElement>products = productCatalogue.getProductList();
		
		
		

		
		
		productCatalogue.addProductToCart(productName);
		
		
		
		

		
		CartPage cartPage = productCatalogue.goToCartPage();
		
		
		
		Boolean match = cartPage.VerifyProductDisplay(productName);
		Assert.assertTrue(match);
		
		CheckoutPage checkoutPage = cartPage.goToCheckout();
		
		checkoutPage.selectCountry("India");
		ConfirmationPage confirmationPage = checkoutPage.submitOrder();
		


		String confirmMessage = confirmationPage.getConfirmationMessage();
		Assert.assertTrue(confirmMessage.equalsIgnoreCase("THANKYOU FOR THE ORDER"));

		
		


	}
}





