import org.testng.annotations.Test;

import io.restassured.RestAssured;

public class OauthAPI {
	
//	@Test
//	public void verifyOauthAPI()
//	{
//		RestAssured.baseURI = "http://65.0.7.2";
//		given().log().all().formParam("client id", )
//		
//	}

}
