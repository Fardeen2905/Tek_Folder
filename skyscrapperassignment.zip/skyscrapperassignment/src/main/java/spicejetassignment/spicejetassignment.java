package spicejetassignment;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class spicejetassignment {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		WebDriverManager.chromedriver().setup();

		WebDriver driver = new ChromeDriver();
		
		driver.get("https://book.spicejet.com/Search.aspx");
		
		driver.manage().window().maximize();
		
		driver.findElement(By.id("ControlGroupSearchView_AvailabilitySearchInputSearchVieworiginStation1_CTXT")).click();
		
		driver.findElement(By.xpath("//a[@value='HYD']")).click();
		
		
		driver.findElement(By.xpath("//a[@value='BLR']")).click();
		
		driver.findElement(By.xpath("//a[normalize-space()='25']")).click();
		
		driver.findElement(By.id("divpaxinfo")).click();
		
		
		
		
		
		
		
		
	
		

	}

}
