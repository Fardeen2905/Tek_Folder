package com.allegis.pages;
import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class JobSearchPage {
    private WebDriver driver;

    

    @FindBy(id = "skill")
    private WebElement skillsInput;
    
    @FindBy(id = "experience")
    private WebElement experienceInput;

    @FindBy(id = "location")
    private WebElement locationInput;

    @FindBy(id = "search-jobs")
    private WebElement searchButton;

    @FindBy(xpath = "//div[@class='jobTupleHeader']")
    private List<WebElement> jobResults;
    
    @FindBy(xpath="//span[contains(text(),'Work from office')]")
	private WebElement workfromoffice;
	
	

    public JobSearchPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void applyFilters(String skill, String experience, String location) {
       
        enterSkill(skill);
        enterExperience(experience);
        enterLocation(location);
        clickSearch();
        waitForSearchResults();
        
    }

    

    private void enterSkill(String skill) {
        skillsInput.sendKeys(skill);
    }
    
    
    private void enterExperience(String experience) {
        experienceInput.sendKeys(experience);
    }

    private void enterLocation(String location) {
        locationInput.sendKeys(location);
    }

    private void clickSearch() {
        searchButton.click();
    }

    private void waitForSearchResults() {
    	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfAllElements(jobResults));
    }

    public boolean isSkillPresent(String skill) {
        for (WebElement jobResult : jobResults) {
            if (jobResult.getText().contains(skill)) {
                return true;
            }
        }
        return false;
    }

    public boolean isLocationPresent(String location) {
        for (WebElement jobResult : jobResults) {
            if (jobResult.getText().contains(location)) {
                return true;
            }
        }
        return false;
    }
    
    public boolean isExperiencePresent(String experience) {
        for (WebElement jobResult : jobResults) {
            if (jobResult.getText().contains(experience)) {
                return true;
            }
        }
        return false;
    }
    
    public void wfhFilter()
    {
    	
    }
    
    
    public void uploadResume() throws InterruptedException, AWTException
    {
        driver.findElement(By.xpath("//div[@class='nI-gNb-drawer__bars']")).click();
        WebDriverWait wait1 = new WebDriverWait(driver,Duration.ofSeconds(5));
        wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(text(),'View & Update Profile')]")));
        driver.findElement(By.xpath("//a[contains(text(),'View & Update Profile')]")).click();
        Thread.sleep(3000);
        JavascriptExecutor js =  (JavascriptExecutor) driver;
  	  js.executeScript("window.scrollBy(0, 400)");
        WebElement resumeUploadButton = driver.findElement(By.xpath("//a[contains(text(),'Upload')]"));
        File file = new File("src\\main\\resources\\Resume.pdf");
        Thread.sleep(3000);
        resumeUploadButton.click();
        
        String filename=file.getAbsolutePath();
   
        StringSelection filedetails=new StringSelection(filename);
        Toolkit.getDefaultToolkit().getSystemClipboard().setContents(filedetails,null);
        Robot robot=new Robot();
        robot.delay(1000);
   
        robot.keyPress(KeyEvent.VK_CONTROL);
        robot.keyPress(KeyEvent.VK_V);
        robot.keyRelease(KeyEvent.VK_V);
        robot.keyRelease(KeyEvent.VK_CONTROL);
   
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.keyRelease(KeyEvent.VK_ENTER);
        
        Thread.sleep(3000);
        
        driver.findElement(By.xpath("//div[@class='resumeParser']/preceding-sibling::div")).click();
        Thread.sleep(3000);
    }
    
    
    public void selectWorkFromOffice()
	{
		workfromoffice.click();
		
	}
    
    
}

