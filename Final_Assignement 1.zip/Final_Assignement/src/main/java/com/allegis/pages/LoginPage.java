package com.allegis.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LoginPage {
    private WebDriver driver;

    @FindBy(xpath = "//input[@placeholder='Enter your active Email ID / Username']")
    private WebElement usernameField;

    @FindBy(xpath = "//input[@type='password']")
    private WebElement passwordField;

    @FindBy(xpath = "//button[@class='btn-primary loginButton']")
    private WebElement loginButton;
    
    
    

    public LoginPage(WebDriver driver) {
        this.driver = driver;
    }
    

    public void login(String username, String password) {
        usernameField.sendKeys(username);
        passwordField.sendKeys(password);
        loginButton.click();
    }

	/*
	 * public String getPageTitle() {
	 * return driver.getTitle();
	 * 
	 * }
	 */
    
   
    
}
