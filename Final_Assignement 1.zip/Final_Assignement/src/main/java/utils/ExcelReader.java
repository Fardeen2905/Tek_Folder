package utils;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class ExcelReader {
    private Workbook workbook;

    public ExcelReader(String filePath) {
        try {
            FileInputStream file = new FileInputStream(filePath);
            workbook = WorkbookFactory.create(file);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Object[][] getSheetData(String sheetName) {
        Sheet sheet = workbook.getSheet(sheetName);
        int rowCount = sheet.getLastRowNum();
        int colCount = sheet.getRow(0).getLastCellNum();

        Object[][] data = new Object[rowCount][colCount];
        for (int i = 1; i <= rowCount; i++) {
            for (int j = 0; j < colCount; j++) {
                Cell cell = sheet.getRow(i).getCell(j);
                cell.setCellType(CellType.STRING);
                data[i - 1][j] = cell.getStringCellValue();
            }
        }
        return data;
    }
}
