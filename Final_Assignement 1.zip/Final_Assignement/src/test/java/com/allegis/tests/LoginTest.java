package com.allegis.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.allegis.basetest.BaseTest;
import com.allegis.pages.*;
import utils.ConfigReader;

public class LoginTest extends BaseTest {
    private WebDriver driver;
    private LoginPage loginPage;

    @BeforeMethod
    public void setUp() {
        //System.setProperty("webdriver.chrome.driver", "path/to/chromedriver");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get(ConfigReader.getProperty("baseUrl"));
        loginPage = new LoginPage(driver);
        sleep(5000);
    }

	
	  @Test(priority = 1) 
	  public void validateLoginPageTitle() throws InterruptedException {
		  String expectedTitle="Jobs - Recruitment - Job Search - Employment - Job Vacancies - Naukri.com";
		  String actualTitle= driver.getTitle(); Assert.assertEquals(actualTitle,expectedTitle,"Login page title is not as expected.");
		  
		  sleep(5000);
	  }
	 

    @Test(priority = 2)
    public void wrongCredentialVerificationTest() {
        loginPage.login(ConfigReader.getProperty("username"), ConfigReader.getProperty("wrongpassword"));
        sleep(5000);
        
    }
    @Test(priority=3)
    public void invalidVerification() 
    {
    	String actual=driver.findElement(By.xpath("//*[@id=\"root\"]/div[4]/div[2]/div/div/div[2]/div/form/div[1]")).getText();
    	sleep(3000);
		String expected="Invalid details. Please check the Email ID - Password combination.";
		Assert.assertEquals(actual, expected,"Invalid Details");
    }
    
    

    @Test(priority = 4)
    public void loginTest() {
        loginPage.login(ConfigReader.getProperty("username"), ConfigReader.getProperty("password"));
        sleep(5000);
        
    }

    @AfterMethod
    public void tearDown() {
        driver.quit();
    }
}
