package com.allegis.basetest;

public class BaseTest {
	protected void sleep(long mills)
	{
		try {
			Thread.sleep(mills);;
		}
		catch(InterruptedException e)
		{
			e.printStackTrace();
		}
	}

}
