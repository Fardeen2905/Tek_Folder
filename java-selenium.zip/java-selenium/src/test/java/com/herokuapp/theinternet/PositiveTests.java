package com.herokuapp.theinternet;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class PositiveTests {

	@Test
	public void loginTest() {
         System.out.println("Test Started");
		// Create driver

		WebDriver driver = new ChromeDriver();
		System.out.println("Browser started");
		sleep(1);
//		open test page
		String url = "https://the-internet.herokuapp.com/login";
		driver.get(url);
		sleep(1);
		driver.manage().window().maximize();
		sleep(1);
		System.out.println("Page is opened");
		
//		driver.findElement(By.name("username")).sendKeys("tomsmith");
//		driver.findElement(By.name("password")).sendKeys("SuperSecretPassword!");
//		driver.findElement(By.xpath("//*[@id=\"login\"]")).click();
//		sleep(5);
		
		sleep(2000);
		
//		String exp_title="The Internet";
//		String act_title=driver.getTitle(); // returns the title of the page
//		
//		if(exp_title.equals(act_title)==true)
//		{
//			System.out.println("test is passed");
//		}
		
		
		
	
		
//		enter username
		
		WebElement username = driver.findElement(By.id("username"));
		username.sendKeys("tomsmith");
	// enter password
		WebElement password = driver.findElement(By.name("password"));
		password.sendKeys("SuperSecretPassword!");
//		click login button
		WebElement logInButton = driver.findElement(By.tagName("button"));
		logInButton.click();

//		verifications
//		new url
		
		
//		logout button is visible
		WebElement logOutButton = driver.findElement(By.xpath("//a[@class='button secondary radius']"));
		logOutButton.click();
//		successful login message
		WebElement successMessage = driver.findElement(By.id("flash"));
		System.out.println(successMessage.getText());
//		driver.close();
		System.out.println("Test Finished");

	}
	
	

	/**
	 * Stop execution for the given amount of time
	 * @param seconds
	 */
	private void sleep(int seconds) {
		try {
			Thread.sleep(seconds * 1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
