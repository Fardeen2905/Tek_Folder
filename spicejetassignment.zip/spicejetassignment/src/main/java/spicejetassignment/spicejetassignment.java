package spicejetassignment;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class spicejetassignment {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		WebDriverManager.chromedriver().setup();

		WebDriver driver = new ChromeDriver();

//		driver.get("https://book.spicejet.com/Search.aspx");

//		driver.manage().window().maximize();
//		
//		driver.findElement(By.id("ControlGroupSearchView_AvailabilitySearchInputSearchVieworiginStation1_CTXT")).click();
//		
//		driver.findElement(By.xpath("//a[@value='HYD']")).click();
//		
//		
//		driver.findElement(By.xpath("//a[@value='BLR']")).click();
//		
//		driver.findElement(By.xpath("//a[normalize-space()='25']")).click();
//		
//		driver.findElement(By.id("divpaxinfo")).click();
//		
//		WebElement staticDropdown = driver.findElement(By.id("ControlGroupSearchView_AvailabilitySearchInputSearchView_DropDownListPassengerType_ADT"));
//		
//		Select dropdown = new Select(staticDropdown);
//		
//		dropdown.selectByIndex(1);

		driver.get("https://www.spicejet.com/");
		// maximize browser window
		driver.manage().window().maximize();

		driver.findElement(By.xpath("//div[@data-testid='to-testID-origin']//input[@type='text']")).click();

		driver.findElement(By.xpath("//div[text()='Delhi']")).click();

		driver.findElement(By.xpath("//div[text()='Hyderabad']")).click();
		Thread.sleep(5000);

		// date
		driver.findElement(By.xpath(
				"//*[@id=\"main-container\"]/div/div[1]/div[3]/div[2]/div[4]/div/div[2]/div[2]/div[3]/div[2]/div/div[2]/div/div[3]/div[1]/div[5]/div/div"))
				.click();
		// audult
		driver.findElement(By.xpath(
				"//div[@class='css-1dbjc4n']//div//div[@class='css-1dbjc4n r-14lw9ot r-11u4nky r-z2wwpe r-1phboty r-rs99b7 r-1loqt21 r-13awgt0 r-ymttw5 r-5njf8e r-1otgn73']//div[@class='css-1dbjc4n r-1awozwy r-18u37iz r-1wtj0ep']"))
				.click();

		for (int i = 1; i < 2; i++) {
			driver.findElement(
					By.xpath("//div[@class='css-1dbjc4n r-k8qxaj r-d9fdf6']//div[1]//div[2]//div[3]//*[name()='svg']"))
					.click();
		}

		// done
		driver.findElement(By.xpath(
				"//*[@id=\"main-container\"]/div/div[1]/div[3]/div[2]/div[5]/div[1]/div/div[2]/div[2]/div/div[2]/div"))
				.click();
		Thread.sleep(2000);

		WebElement staticDropdown = driver
				.findElement(By.xpath("//*[@id=\"main-container\"]/div/div[1]/div[3]/div[2]/div[5]/div[2]/div"));

		Select dropdown = new Select(staticDropdown);
		dropdown.selectByIndex(1);

		// search flight
		driver.findElement(By.xpath(
				"//div[@id='main-container']/div/div[@class='css-1dbjc4n r-14lw9ot']/div[3]/div[2]/div[7]/div[@class='css-1dbjc4n']/div"))
				.click();

		Thread.sleep(5000);
		// click on continue

		driver.findElement(
				By.xpath("//*[@id=\"list-results-section-0\"]/div[5]/div[1]/div/div[1]/div/div[1]/div[3]/div/div"));

		JavascriptExecutor js = (JavascriptExecutor) driver;

		js.executeScript("window.scrollBy(0,500)");
		Thread.sleep(2000);

		driver.findElement(By.xpath("//*[@id=\"main-container\"]/div/div[1]/div[5]/div/div/div[3]/div[2]")).click();
	}

}