package demo;

public class Example {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
			// System.out.println(1);
			
			// while Do-while for
			
			int i=10;
			while(i>=1) {
				System.out.println(i);
				i--;
			}

	}

}
