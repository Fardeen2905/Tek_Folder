package Objects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class GoogleSearchpage {
	
	WebDriver driver;
	
	public GoogleSearchpage(WebDriver driver) {
		
		this.driver= driver;		
	}
	
	
	By searchbox = By.xpath("//input[@name='q']");
	
	public void searchgoogle(String Searchinput)
	{
		driver.findElement(searchbox).sendKeys(Searchinput);
	}

}
