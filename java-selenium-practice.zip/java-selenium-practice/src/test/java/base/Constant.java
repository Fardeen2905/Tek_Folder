package base;

public class Constant {

	public static class Testconstant{
		public static final String username = "Admin";
	}

}
