//package TestMethods1;
//
//import org.testng.annotations.BeforeClass;
//import org.testng.annotations.Test;
//
//public class Test1 extends Baseclass{
//	
//	
//	@BeforeClass
//	public void setUp() {
//		initializeDriver();
//	}
//	
//	@Test(priority=2)
//	public void testLoginValidCredentials()
//	
//	
//	
//
//}