package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Calendar {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		WebDriverManager.chromedriver().setup();

		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.makemytrip.com/hotels/");
		
		driver.findElement(By.id("checkin")).click();
		String day="//*[contains(@class,'DayPicker-Day') and text()='14']";
		driver.findElement(By.xpath(day)).click();
		
		Thread.sleep(2000);
		
		driver.findElement(By.id("checkout")).click();
		
		String checkoutday="//*[contains(@class,'DayPicker-Day') and text()='15']";
		
		Thread.sleep(2000);
		
		driver.findElement(By.xpath(checkoutday)).click();
		
		

	}

}
