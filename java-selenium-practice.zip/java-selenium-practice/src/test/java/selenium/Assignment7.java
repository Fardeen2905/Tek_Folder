package selenium;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Assignment7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		WebDriver driver = new ChromeDriver();

		driver.get("https://rahulshettyacademy.com/AutomationPractice/");

		List<WebElement> rows = driver.findElements(By.xpath("//table[@name='courses']//tr"));

		System.out.println("Number of rows in a table are " + rows.size());

		List<WebElement> columns = driver.findElements(By.xpath("//table[@name='courses']//th"));

		System.out.println("Number of columns in a table are " + columns.size());
		
//		System.out.println(driver.findElement(By.xpath("//table[@name='courses']//tr[3]//td[1]")).getText());
//		System.out.println(driver.findElement(By.xpath("//table[@name='courses']//tr[3]//td[2]")).getText());
//		System.out.println(driver.findElement(By.xpath("//table[@name='courses']//tr[3]//td[3]")).getText());
		
		List<WebElement> rowsize = driver.findElements(By.xpath("//table[@name='courses']//tr"));
		
		List<WebElement> columnsize = driver.findElements(By.xpath("//table[@name='courses']//th"));
		
		for(int i=1;i<=rowsize.size();i++) {
			for(int j=1;j<=columnsize.size();j++) {
				
			
			
			System.out.println(driver.findElement(By.xpath("//table[@name='courses']//tr["+ i +"]//td["+ i+ "]")).getText());
			
		}

	}

}
}
