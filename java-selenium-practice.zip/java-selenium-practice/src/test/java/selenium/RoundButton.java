package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class RoundButton {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		WebDriverManager.chromedriver().setup();

		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.makemytrip.com/");
		
		driver.findElement(By.xpath("//a[@href='https://www.makemytrip.com/hotels/']")).click();
		
		driver.findElement(By.xpath("//span[@class='grpBkngOpt__item--opt']")).click();
		
		System.out.println(driver.findElement(By.xpath("//span[@class='grpBkngOpt__item--opt']")).isEnabled());
		
//		System.out.println(driver.findElement(By.xpath("//span[@class='grpBkngOpt__item--opt']")));
		
		Thread.sleep(2000);
		
//		String round="//*[contains(@class,'grpBkngOpt__item--opt') and text()='Group Deals']";
		
//		driver.findElement(By.xpath("//span[@class='grpBkngOpt__item.selected']//li[2]")).click();
		
		
		driver.findElement(By.xpath("//span[text()='Group Deals']")).click();
		
		
		System.out.println(driver.findElement(By.xpath("//span[text()='Group Deals']")).isEnabled());
		

		
//		driver.findElement(By.xpath("//input[@id='city']")).click();
		
//		driver.findElement(By.xpath("//p[@class='sr_city']")).click();
		
//		driver.findElement(By.xpath("//span[text()='Chennai']")).click();

//		String city="//*[contains(@class,'blackText') and text()='Bangalore']";
//		
//		driver.findElement(By.xpath(city)).click();
		
		
		

	}

}
