package selenium;

import static org.testng.Assert.assertEquals;

import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SeleniumAssignment {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.selenium.dev/documentation/en/");
		WebElement searchBox = driver.findElement(By.id("docsearch-input"));
		searchBox.sendKeys("InvalidTerm");
		searchBox.submit();
		
		
		 
		        

		        WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));

		        wait.until(ExpectedConditions.titleContains("Search Results"));

		        WebElement firstSearchResult = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("path")));

		        assertEquals(true, firstSearchResult.getText().contains("WebDriver"), "First search result does not contain 'WebDriver'");

		        WebElement nonExistentElement = driver.findElement(By.id("non-existent-id"));

		        nonExistentElement.click();
		 
		        

		        WebElement dropdown = driver.findElement(By.id("selectNav"));

		        Select select = new Select(dropdown);

		        select.selectByIndex(10);

				System.out.println("Selected option in the dropdown: " + select.getFirstSelectedOption());

		        WebElement promptButton = driver.findElement(By.id("promptButton"));

		        promptButton.click();

		        Alert promptAlert = wait.until(ExpectedConditions.alertIsPresent());

		        String promptText = promptAlert.getText();

		        System.out.println("Prompt text: " + promptText);

		        promptAlert.accept();

		        WebElement promptResult = driver.findElement(By.id("promptResult"));

		        assertEquals("You entered: Selenium", promptResult.getText(), "Prompt result does not match");
		 
		        driver.quit();

		    }

		

}
	
	

