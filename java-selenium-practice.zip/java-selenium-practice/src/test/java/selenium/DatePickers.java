package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class DatePickers {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		String month="May 2001";
		String day="29";
		
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://demo.automationtesting.in/Datepicker.html");
		
		driver.manage().window().maximize();
		
		driver.findElement(By.className("imgdp")).click();
		
		Thread.sleep(2000);
		
		System.out.println(driver.findElement(By.xpath("//div[@class='ui-datepicker-title']")).getText());
		
		while(true)
		{
		
		String text = driver.findElement(By.xpath("//div[@class='ui-datepicker-title']")).getText();
		
		if(text.equals(month))
		{
			break;
		}
		else
		{
			driver.findElement(By.xpath("//span[@class='ui-icon ui-icon-circle-triangle-e']")).click();
		}

	}

}
	
}
