package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class checkbox {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		WebDriverManager.chromedriver().setup();

		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.makemytrip.com/hotels/");
		
		driver.manage().window().maximize();
		
		Actions b = new Actions(driver);
		
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//button[@id='hsw_search_button']")).click();
		
		Thread.sleep(2000);
		
		b.sendKeys(org.openqa.selenium.Keys.PAGE_DOWN).build().perform();
		
//		.sendKeys(org.openqa.selenium.Keys.PAGE_DOWN).build().perform();
		
		Thread.sleep(3000);
		
		WebElement a=driver.findElement(By.xpath("//div[@class='_Hlisting']//div[4]//div[1]//div[@class='appendBottom35']//div[@id='PRICE_BUCKET']//div[@class='priceBucketFilter']//ul//li[3]//label"));
		
		
		Thread.sleep(2000);
		
		if(!a.isSelected()) {
			a.click();
		}
		
//		driver.findElement(By.xpath("//label[contains(text(),'₹ 4000 - ₹ 7000')]")).click();
//		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", a);
		
		
		

	}

}
