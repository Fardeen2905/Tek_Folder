package selenium;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import io.github.bonigarcia.wdm.WebDriverManager;


public class Assignment6 {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		WebDriverManager.chromedriver().setup();

		WebDriver driver = new ChromeDriver();

		driver.get("https://rahulshettyacademy.com/AutomationPractice/");

		driver.findElement(By.xpath("//*[@id='checkbox-example']/fieldset/label[2]/input")).click();

		String opt = driver.findElement(By.xpath("//*[@id='checkbox-example']/fieldset/label[2]")).getText();

		Thread.sleep(2000);
		
		WebElement staticDropdown = driver.findElement(By.id("dropdown-class-example"));

		Select dropdown = new Select(staticDropdown);
		dropdown.selectByVisibleText(opt);
		
		driver.findElement(By.name("enter-name")).sendKeys(opt);
		driver.findElement(By.id("alertbtn")).click();
		
		System.out.println(driver.switchTo().alert().getText());
		
		String text = driver.switchTo().alert().getText();
		
		if(text.contains(opt))
		{
			System.out.println("Alert message success");
		}
		else {
			System.out.println("something wrong with execution");
		}
		
		
		

//		driver.findElement(By.id("checkBoxOption2")).click();

//		driver.findElement(By.id("checkBoxOption2")).getText();

//		System.out.println(driver.findElement(By.xpath("//label//input[@id='checkBoxOption2']")).isSelected());

	}
}
