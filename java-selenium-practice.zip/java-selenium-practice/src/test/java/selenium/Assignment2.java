package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Assignment2 {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		WebDriver driver = new ChromeDriver();

		driver.get("https://rahulshettyacademy.com/angularpractice/");

		Thread.sleep(2000);
		
		driver.manage().window().maximize();

		driver.findElement(By.name("name")).sendKeys("fardeen");
		driver.findElement(By.name("email")).sendKeys("fmahammad@teksystems.com");

		driver.findElement(By.cssSelector("input[placeholder='Password']")).sendKeys("fardeen@2905");

		driver.findElement(By.id("exampleCheck1")).click();

		WebElement staticDropdown = driver.findElement(By.id("exampleFormControlSelect1"));

		Select dropdown = new Select(staticDropdown);
		dropdown.selectByVisibleText("Male");
		
		
		driver.findElement(By.id("inlineRadio1")).click();
		
		driver.findElement(By.name("bday")).sendKeys("02/02/1992");
		
		Thread.sleep(1000);
		
		
		
		driver.findElement(By.cssSelector("input[type='date']")).click();
		
		driver.findElement(By.cssSelector("input[value='Submit']")).click();
		
		System.out.println(driver.findElement(By.xpath("//div[@class='alert alert-success alert-dismissible']")).getText());
	}

}
