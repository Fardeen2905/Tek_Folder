package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Orangehrm {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://opensource-demo.orangehrmlive.com/");

		Thread.sleep(2000);

		driver.findElement(By.name("username")).sendKeys("Admin");
		Thread.sleep(2000);
		driver.findElement(By.name("password")).sendKeys("admin123");
		Thread.sleep(2000);
		driver.findElement(
				By.xpath("//button[@class='oxd-button oxd-button--medium oxd-button--main orangehrm-login-button']"))
				.click();
		Thread.sleep(5000);
//		driver.findElement(By.xpath("//header//div//div[2]//ul[1]//li[@class]")).click();
//		Thread.sleep(2000);
		driver.findElement(By.xpath(
				"//div[@class='oxd-layout']//aside[@class='oxd-sidepanel']//ul//li[@class='oxd-main-menu-item-wrapper'][5]"))
				.click();
		Thread.sleep(5000);

//		WebElement staticDropdown = driver.findElement(By.xpath("//header//div//div[2]//ul[1]//li[@class]"));
//
//		Select dropdown = new Select(staticDropdown);
//
//		dropdown.selectByVisibleText("About");

	}

}
