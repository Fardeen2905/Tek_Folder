package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class MakeMyTripExercise {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();

		driver.get("https://www.makemytrip.com/");
		driver.manage().window().maximize();
		Thread.sleep(2000);
		driver.get("https://www.makemytrip.com/hotels/");
		driver.findElement(By.xpath("//label[@for='city']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@placeholder='Where do you want to stay?']")).sendKeys("Bengaluru");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//span[@class='blackText' and text()='Bangalore']")).click();

	}

}
