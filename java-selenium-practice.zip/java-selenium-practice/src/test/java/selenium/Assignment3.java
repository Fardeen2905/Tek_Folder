package selenium;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Assignment3 {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		WebDriver driver = new ChromeDriver();

		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		driver.get("https://rahulshettyacademy.com/loginpagePractise/");

		driver.findElement(By.xpath("//input[@id='username']")).sendKeys("rahulshettyacademy");

		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("learning");

		driver.findElement(By.xpath("(//span[@class='checkmark'])[2]")).click();
		
		Thread.sleep(4000);

		driver.findElement(By.xpath("//button[@id='okayBtn']")).click();

		

//		driver.switchTo().alert().accept();

		WebElement staticDropdown = driver.findElement(By.xpath("//select[@class='form-control']"));

		Select dropdown = new Select(staticDropdown);
		dropdown.selectByIndex(2);
		
		driver.findElement(By.xpath("//input[@id='terms']")).click();
		
		
		
		driver.findElement(By.xpath("//input[@id='signInBtn']")).click();
		
		List<WebElement> products = driver.findElements(By.cssSelector(".card-footer .btn-info"));
		
		for(int i=0;i<products.size();i++)
		{
			products.get(i).click();
		}
		
		driver.findElement(By.cssSelector(".nav-link.btn.btn-primary")).click();
		

	}

}
 