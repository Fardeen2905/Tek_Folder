package selenium;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Assignment8 {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");
		
//		driver.findElement(By.xpath("//input[@id='autocomplete']")).click();
		
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//input[@id='autocomplete']")).sendKeys("ind");
		
		Thread.sleep(3000);
		
		List<WebElement> dynamicList = driver.findElements(By.cssSelector(".ui-menu-item-wrapper"));
		
		for(int i=0;i<dynamicList.size();i++) {
			String text = dynamicList.get(i).getText();
			System.out.println("Text is"+text);
			if(text.contains("Indonesia")) {
				dynamicList.get(i).click();
				break;
			}
		}

	}

}
