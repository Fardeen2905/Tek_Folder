package com.junit.tests;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class FirstSeleniumJUnitTest {

	WebDriver webDriver;

	@Before
	public void before() {

		// Execute the Code

		// Download the Web Driver Executable
		// Set the Path to Web Driver Executable
		WebDriverManager.chromedriver().setup(); // this one is not necessary

		// Create an instance of WebDriver
		webDriver = new ChromeDriver();

	}

	@Test
	public void testGoogleDotCom() {

//		// Execute the Code
//
//		// Download the Web Driver Executable
//		// Set the Path to Web Driver Executable
//		WebDriverManager.chromedriver().setup(); // this one is not necessary
//		// Create an instance of WebDriver
//		WebDriver webDriver = new ChromeDriver();

		// WebDriver - Launch up http://www.google.com
		webDriver.get("https://www.google.com");
		webDriver.manage().window().maximize();

//		System.out.println(webDriver.getCurrentUrl());

//		System.out.println(webDriver.getTitle());

		String actualTitle = webDriver.getTitle();
		String expectedTitle = "Google";

		// Check the output
		// WebDriver - Title is Google
		assertEquals(expectedTitle, actualTitle);

//		webDriver.quit();

	}

	@Test
	@Ignore
	public void testFacebookDotCom() {

//		// Execute the Code
//
//		// Download the Web Driver Executable
//		// Set the Path to Web Driver Executable
//		WebDriverManager.chromedriver().setup(); // this one is not necessary
//		// Create an instance of WebDriver
//		WebDriver webDriver = new ChromeDriver();

		// WebDriver - Launch up http://www.facebook.com
		webDriver.get("http://www.facebook.com");
		webDriver.manage().window().maximize();

		System.out.println(webDriver.getCurrentUrl());

		System.out.println(webDriver.getTitle());

		String actualTitle = webDriver.getTitle();
		String expectedTitle = "Facebook – log in or sign up";

		// Check the output
		// WebDriver - Title is Google
		assertEquals(expectedTitle, actualTitle);

//		webDriver.quit();

	}
	
	@After
	public void after() {
		System.out.println("I'm, Executed");
		webDriver.quit();
	}
	

}
