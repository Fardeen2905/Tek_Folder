package com.junit.tests;

import static org.junit.Assert.*;

import org.junit.Test;

class SimpleClass{
	
	public int sum(int[] numbers) {
		int sum=0;
		
		for(int i=0;i<numbers.length;i++) {
			sum+=numbers[i];
		}
		
		return sum;
	}




}



