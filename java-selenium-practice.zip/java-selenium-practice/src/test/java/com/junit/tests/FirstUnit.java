package com.junit.tests;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class FirstUnit {

	@Test
	public void test() {
		
		//Execute the Code
		
		SimpleClass simpleClass = new SimpleClass();
		
		int actualResult = simpleClass.sum(new int[] {12,15,18});
		
		System.out.println(actualResult);
		
		//Check the Output
		
		int expectedResult = 45;
		
		assertEquals(expectedResult, actualResult);
		
		//No checks
		//Checks
		//Absence of Failure is Success
		
	}
	
	@Test
	public void testFor0Elements() {
		
		//Execute the Code
		
		SimpleClass simpleClass = new SimpleClass();
		
		int actualResult = simpleClass.sum(new int[] {});
		
		System.out.println(actualResult);
		
		//Check the Output
		
		int expectedResult = 0;
		
		assertEquals(expectedResult, actualResult);
		
		//No checks
		//Checks
		//Absence of Failure is Success
		
	}
	
	@Test
	public void testFor2Elements() {
		
		//Execute the Code
		
		SimpleClass simpleClass = new SimpleClass();
		
		int actualResult = simpleClass.sum(new int[] {12,15});
		
		System.out.println(actualResult);
		
		//Check the Output
		
		int expectedResult = 27;
		
		assertEquals(expectedResult, actualResult);
		
		//No checks
		//Checks
		//Absence of Failure is Success
		
	}
	
	@Test
	public void testFor5Elements() {
		
		//Execute the Code
		
		SimpleClass simpleClass = new SimpleClass();
		
		int actualResult = simpleClass.sum(new int[] {2,6,8,15,18});
		
		System.out.println(actualResult);
		
		//Check the Output
		
		int expectedResult = 49;
		
		assertEquals(expectedResult, actualResult);
		
		//No checks
		//Checks
		//Absence of Failure is Success
		
	}
}