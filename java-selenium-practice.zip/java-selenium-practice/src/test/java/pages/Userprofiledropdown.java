//package pages;
//
//public class Userprofiledropdown extends Baseclass{
//
//	public static void clickUserProfile() thows InterruptedException{
//		
//    	implicit();
//        WebElement userprofile=driver.findElement( By.xpath("//i[@class='oxd-icon bi-caret-down-fill oxd-userdropdown-icon']"));
//        userprofile.click();
//        Thread.sleep(2000);
//        WebElement about=driver.findElement(By.cssSelector("a.oxd-userdropdown-link"));
//        about.click();
//        Thread.sleep(5000);
//
//       WebElement close=driver.findElement(By.cssSelector("button[class='oxd-dialog-close-button oxd-dialog-close-button-position']"));
//        close.click();
//    }
//
//}
//	
//		
//		
//
