package com.allegis.tests;

import java.awt.AWTException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.allegis.basetest.BaseTest;
import com.allegis.pages.JobSearchPage;
import utils.ConfigReader;
import utils.ExcelReader;

public class JobSearchTest extends BaseTest {
	private WebDriver driver;
	private JobSearchPage jobSearchPage;

	@BeforeClass
	public void setUp() {
		driver = new ChromeDriver();
		driver.get(ConfigReader.getProperty("baseUrl"));
		jobSearchPage = new JobSearchPage(driver);
		sleep(5000);
	}

	@DataProvider(name = "jobSearchData")
	public Object[][] getJobSearchData() {
		// Read data from Excel sheet
		ExcelReader excelReader = new ExcelReader("src\\main\\resources\\ExcelFile.xlsx");
		Object[][] data = excelReader.getSheetData("Sheet1");
		return data;
		
	}

	@Test(dataProvider = "jobSearchData")
	public void searchJobs(String skill, String experience, String location) {
		jobSearchPage.applyFilters(skill, experience, location);
		Assert.assertTrue(jobSearchPage.isSkillPresent(skill), "Skill not found in search results.");
		Assert.assertTrue(jobSearchPage.isExperiencePresent(experience), "Experience not found in search results.");
		Assert.assertTrue(jobSearchPage.isLocationPresent(location), "Location not found in search results.");
		sleep(5000);
	}

	@Test
	public void filteringWfh() {
		jobSearchPage.selectWorkFromOffice();
		sleep(5000);
	}

	@Test()
	public void resumeUploading() throws InterruptedException, AWTException {
		jobSearchPage.uploadResume();
		sleep(5000);
	}

	@AfterClass
	public void tearDown() {
		driver.quit();
	}
}
