package com.allegis.tests;

import java.awt.AWTException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.allegis.basetest.BaseTest;
import com.allegis.pages.*;
import utils.ConfigReader;
import utils.ExcelReader;

public class LoginTest extends BaseTest {
    private WebDriver driver;
    private LoginPage loginPage;
    private JobSearchPage jobSearchPage;
    private ProfilePage profilePage;

    @BeforeClass
    public void setUp() {
        
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get(ConfigReader.getProperty("baseUrl"));
        loginPage = new LoginPage(driver);
        
    }
    

	
	  @Test() 
	  public void validateLoginPageTitle() throws InterruptedException {
		  String expectedTitle="Jobs - Recruitment - Job Search - Employment - Job Vacancies - Naukri.com";
		  String actualTitle= driver.getTitle(); 
		  Assert.assertEquals(actualTitle,expectedTitle,"Login page title is not as expected.");
		  
		  
	  }
	 

//    @Test(dependsOnMethods="validateLoginPageTitle")
//    public void wrongCredentialVerificationTest() throws InterruptedException {
//    	
//    	Thread.sleep(3000);
//        loginPage.login(ConfigReader.getProperty("username"), ConfigReader.getProperty("wrongpassword"));
//        
//        
//    }
		/*
		 * @Test() public void invalidVerification() { String
		 * actual=driver.findElement(By.xpath(
		 * "//*[@id=\"root\"]/div[4]/div[2]/div/div/div[2]/div/form/div[1]")).getText();
		 * sleep(3000); String
		 * expected="Invalid details. Please check the Email ID - Password combination."
		 * ; Assert.assertEquals(actual, expected,"Invalid Details"); }
		 */
    
    

    @Test(dependsOnMethods="validateLoginPageTitle")
    public void loginWithCredentials() throws InterruptedException {
    	//driver.findElement(By.xpath("//a[contains(text(),'Login')]")).click();
        loginPage.login(ConfigReader.getProperty("username"), ConfigReader.getProperty("password"));
       
        
        
    }
    
    @Test(dependsOnMethods="loginWithCredentials")
    public void gotoProfile() throws InterruptedException
    {
    	profilePage = new ProfilePage(driver);
    	profilePage.goToProfile();
    	
    }
    
    
    
//    @DataProvider(name = "jobSearchData")
//	public Object[][] getJobSearchData() {
//		// Read data from Excel sheet
//		ExcelReader excelReader = new ExcelReader("src\\main\\resources\\ExcelFile.xlsx");
//		Object[][] data = excelReader.getSheetData("Sheet1");
//		return data;
//		
//	}
//
//	@Test(dataProvider = "jobSearchData")
//	public void searchJobs(String skill, String experience, String location) {
//		jobSearchPage.applyFilters(skill, experience, location);
//		Assert.assertTrue(jobSearchPage.isSkillPresent(skill), "Skill not found in search results.");
//		Assert.assertTrue(jobSearchPage.isExperiencePresent(experience), "Experience not found in search results.");
//		Assert.assertTrue(jobSearchPage.isLocationPresent(location), "Location not found in search results.");
//		sleep(5000);
//	}
//
//	@Test
//	public void filteringWfh() {
//		jobSearchPage.selectWorkFromOffice();
//		sleep(5000);
//	}
//
//	@Test()
//	public void resumeUploading() throws InterruptedException, AWTException {
//		jobSearchPage.uploadResume();
//		sleep(5000);
//	}

	/*
	 * @AfterClass public void tearDown() { driver.quit(); }
	 */
}
