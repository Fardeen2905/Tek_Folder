package com.allegis.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ProfilePage extends BasePage {

	private WebDriver driver;
	
	@FindBy(xpath="//div[@class='nI-gNb-drawer__icon-img-wrapper']")
	private WebElement profileMenuBar;
	
    public ProfilePage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver,this);
    }
	
	public void goToProfile() throws InterruptedException
	{
		Thread.sleep(2000);
		System.out.println(driver.getCurrentUrl())
;		profileMenuBar.click();
		WebElement viewProfile =  driver.findElement(By.xpath("//a[contains(text(),'View & Update Profile')]"));
		waitUntillElementAppears(driver,viewProfile);
		
	}
	
}
