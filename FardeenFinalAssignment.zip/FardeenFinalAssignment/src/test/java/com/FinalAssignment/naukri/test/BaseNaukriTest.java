package com.FinalAssignment.naukri.test;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BaseNaukriTest {
	
	private Properties properties ;
	private String url,useremail,userpassword,wrongpassword;


    public WebDriver getDriver(WebDriver driver) throws IOException {

		this.properties = new Properties();
        FileInputStream fileInputStream = new FileInputStream("src/main/Resources/config.properties");
        properties.load(fileInputStream);
        fileInputStream.close();
        url = properties.getProperty("url");
        useremail = properties.getProperty("email");
        userpassword=properties.getProperty("password");
        wrongpassword=properties.getProperty("wrongpassword");
        try {
			driver = new ChromeDriver();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return driver;
    }

	
    public String getUseremail() throws IOException
    
    {
        return useremail;
    	
    }

    public String getUserPassword() throws IOException
    
    {
        return userpassword;
    	
    }
    
    public String getWrongUserPassword() throws IOException
    
    {
        return wrongpassword;
    	
    }
    
	public void goToNaukriHomePage(WebDriver driver) throws IOException {
		 
	           driver.get(url);
	           driver.manage().window().maximize();
	           JavascriptExecutor js = (JavascriptExecutor) driver;
	           js.executeScript("window.localStorage.clear();");
	           js.executeScript("window.sessionStorage.clear();");
	           js.executeScript("window.location.reload();");
	}
    public  void quitDriver(WebDriver driver) {
        
        driver.quit();

}

}
