package com.FinalAssignment.naukri.test;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.FinalAssignment.naukri.pages.NaukriHomePage;



public class NaukriHomePageTest extends BaseNaukriTest{
	

	private WebDriver driver;
	private NaukriHomePage naukri;
	
	  @BeforeClass
	  public void setup() throws IOException {
		  this.driver=getDriver(driver);
		  goToNaukriHomePage(driver);
		  naukri = new NaukriHomePage(driver);
	  }
	  
	  
  @Test
  public void validateLoginPage() {
	  String expected = "Jobs - Recruitment - Job Search - Employment - Job Vacancies - Naukri.com";
	  String actual = driver.getTitle();
	  
	  Assert.assertEquals("Login Page Title cannot be Validated", actual,expected);
	  Reporter.log("Login Title Page Validated");
  }

  
  @Test(dependsOnMethods="validateLoginPage")
  public void validateLoginUserDetails() throws IOException, InterruptedException {
	  Reporter.log("Entering User login Details");
	  naukri.clickDisplayLoginButton();
	  
	  
	  WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
      wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(text(),'Register for free')]")));
      
      String userEmail = getUseremail();
      String userPassword = getUserPassword();
      naukri.enterUserEmail(userEmail);
      naukri.enterPassword(userPassword);
      naukri.submitLoginDetails();
      Thread.sleep(2000);
      String currentUrl = driver.getCurrentUrl();
      
      Assert.assertTrue(currentUrl.contains("homepage"));
      Reporter.log("Login Succesfull");
  }
  
  
  
  @Test(dependsOnMethods="validateLoginUserDetails")
  public void uploadResume() throws InterruptedException, AWTException
  {
      driver.findElement(By.xpath("//div[@class='nI-gNb-drawer__bars']")).click();
      WebDriverWait wait1 = new WebDriverWait(driver,Duration.ofSeconds(5));
      wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(text(),'View & Update Profile')]")));
      driver.findElement(By.xpath("//a[contains(text(),'View & Update Profile')]")).click();
      Thread.sleep(3000);
      JavascriptExecutor js =  (JavascriptExecutor) driver;
	  js.executeScript("window.scrollBy(0, 400)");
      WebElement resumeUploadButton = driver.findElement(By.xpath("//a[contains(text(),'Upload')]"));
      File file = new File("src/main/data/RohithKarthikeya.pdf");
      Thread.sleep(3000);
      resumeUploadButton.click();
      
      String filename=file.getAbsolutePath();

      StringSelection filedetails=new StringSelection(filename);
      Toolkit.getDefaultToolkit().getSystemClipboard().setContents(filedetails,null);
      Robot robot=new Robot();
      robot.delay(1000);

      robot.keyPress(KeyEvent.VK_CONTROL);
      robot.keyPress(KeyEvent.VK_V);
      robot.keyRelease(KeyEvent.VK_V);
      robot.keyRelease(KeyEvent.VK_CONTROL);
 
      robot.keyPress(KeyEvent.VK_ENTER);
      robot.keyRelease(KeyEvent.VK_ENTER);
      
      Thread.sleep(3000);
      
      driver.findElement(By.xpath("//div[@class='resumeParser']/preceding-sibling::div")).click();
      Thread.sleep(3000);
      
      
      //delete the resume after uploading so that we can upload next time
      driver.findElement(By.xpath(" //i[contains(text(),'deleteOneTheme')]")).click();
      
      wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//p[contains(text(),'Are you sure you want to delete the resume?')]")));
      driver.findElement(By.xpath("//p[contains(text(),'Are you sure you want to delete the resume?')]/following-sibling::div/child::button")).click();
      Thread.sleep(3000);
  }
  
  
  
@Test(dependsOnMethods="uploadResume")
public void logoutFromNaukri() throws InterruptedException
{
    Thread.sleep(3000);
    driver.findElement(By.xpath("//div[@class='nI-gNb-drawer__bars']")).click();
    WebDriverWait wait1 = new WebDriverWait(driver,Duration.ofSeconds(5));
    wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(text(),'View & Update Profile')]")));
    driver.findElement(By.xpath("//a[contains(text(),'Logout')]")).click();
    Assert.assertTrue(driver.getCurrentUrl().contains("https://www.naukri.com"));
    Reporter.log("Logout Succesfull");
}


@Test(dependsOnMethods="logoutFromNaukri")
public void validateInvalidLoginUserDetails() throws IOException, InterruptedException
{
	Thread.sleep(2000);
	driver.findElement(By.xpath("//a[contains(text(),'Login')]")).click();
	WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(text(),'Register for free')]")));
    String userEmail = getUseremail();
    String wrongUserPassword = getWrongUserPassword();
    naukri.enterUserEmail(userEmail);
    naukri.enterPassword(wrongUserPassword);
    naukri.submitLoginDetails();
    Thread.sleep(2000);
    Assert.assertTrue(driver.findElement(By.xpath("//div[contains(text(),'Invalid details')]")).isDisplayed());
    Reporter.log("Validation of Invalid Credentials is Also Succesfull");
    driver.findElement(By.xpath("//a[@class='close']/i")).click();
}


@DataProvider(name = "excelData")
public Object[][] getExcelData() throws IOException, InvalidFormatException {
	File file = new File("src/main/Resources/naukritest.xlsx");

    // Create a package object
    try (OPCPackage pkg = OPCPackage.open(file)) {
        // Create a workbook
        try (XSSFWorkbook workbook = new XSSFWorkbook(pkg)) {
            XSSFSheet sheet = workbook.getSheetAt(0);

            // Iterate through each row
            Row row = sheet.getRow(0);
            String value1 = row.getCell(0).getStringCellValue();
            String value2 = row.getCell(1).getStringCellValue();

            workbook.close();
            return new Object[][]{{value1, value2}};
    }
      }
	
    
}


@Test(dependsOnMethods="validateInvalidLoginUserDetails")
public void goToItJobsPage() {
  naukri.goToItJobs();
}

@Test(dependsOnMethods="goToItJobsPage")
public void selectWorkFromHome() throws InterruptedException
{
  Thread.sleep(2000);
  JavascriptExecutor js =  (JavascriptExecutor) driver;
  js.executeScript("window.scrollBy(0, 300)");
  naukri.selectWorkFromOffice();
}
@Test(dataProvider = "excelData",dependsOnMethods="selectWorkFromHome")
public void applySearchFilters(String Skills,String location) throws InterruptedException
{
  
  naukri.applyFilters(Skills,location);
  Assert.assertTrue(naukri.compareSearchResults("Java, Javascript", "Bengaluru"));
  Reporter.log("Search Results Matched with the excel Data");
  
}
  @AfterClass
  public void closeAll() throws InterruptedException {
	  Thread.sleep(5000);
	  quitDriver(driver);
  }

}
