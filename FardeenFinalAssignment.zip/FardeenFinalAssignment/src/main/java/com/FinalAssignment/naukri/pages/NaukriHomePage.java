package com.FinalAssignment.naukri.pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class NaukriHomePage {
	
	@FindBy(xpath="//a[contains(text(),'Login')]")
	private WebElement loginButton;
	
	@FindBy(xpath="//label[contains(text(),'Email ID')]/following-sibling::input")
	private WebElement userEmail;
	
	@FindBy(xpath="//label[contains(text(),'Password')]/following-sibling::input")
	private WebElement userPassword;
	
	@FindBy(xpath="//button[contains(text(),'Login')]")
	private WebElement loginFormButton;
	
	@FindBy(xpath="//div[contains(text(),'Jobs')]")
	private WebElement jobsButton;
	
	@FindBy(xpath="//span[contains(text(),'Work from office')]")
	private WebElement workfromoffice;
	
	private WebDriver driver;
	
	@FindBy(xpath="//div[@class='nI-gNb-sb__main']")
	private WebElement searchJobsButton;
	
	public NaukriHomePage(WebDriver driver)
	{

		this.driver = driver;
		PageFactory.initElements(driver,this);
	}
	public void clickDisplayLoginButton() 
	{
		loginButton.click();
	}
	
	public void enterUserEmail(String uemail)
	{
		userEmail.sendKeys(uemail);
	}
	
	public void enterPassword(String upass)
	{
		userPassword.sendKeys(upass);
	}
	
	public void submitLoginDetails()
	{
		loginFormButton.click();
	}
	
	public void goToItJobs()
	{
		Actions actions = new Actions(driver);
		actions.moveToElement(jobsButton).perform();
		
		driver.findElement(By.xpath("//div[contains(text(),'IT jobs')]/parent::a")).click();
		
	}
	
	public void selectWorkFromOffice()
	{
		workfromoffice.click();
		
	}
	
	public void applyFilters(String skills,String location) throws InterruptedException
	{
		searchJobsButton.click();
		
		
        WebDriverWait wait1 = new WebDriverWait(driver,Duration.ofSeconds(5));
        wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[contains(@placeholder,'Enter keyword / designation / companies')]")));
        
        driver.findElement(By.xpath("//input[contains(@placeholder,'Enter keyword / designation / companies')]")).sendKeys(skills);
        driver.findElement(By.xpath("//input[contains(@placeholder,'Enter location')]")).clear();
        driver.findElement(By.xpath("//input[contains(@placeholder,'Enter location')]")).sendKeys(location);
        
        Thread.sleep(3000);
        
        driver.findElement(By.xpath("//span[contains(text(),'Search')]")).click();
	}
	
	public boolean compareSearchResults(String skills,String location) throws InterruptedException
	{
		Thread.sleep(3000);
		WebElement resultsDisplay = driver.findElement(By.xpath("//h1"));
		String titleAttribute = resultsDisplay.getAttribute("title");
		System.out.println(titleAttribute);
		System.out.println(skills+" "+location);
		if(titleAttribute.contains(skills) && titleAttribute.contains(location))
		{
			return true;
		}
		return false;
	}

}
