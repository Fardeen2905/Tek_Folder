package Assignment;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Naukri_Assignment {

	public static void main(String[] args) throws InterruptedException, AWTException {
		// TODO Auto-generated method stub

		WebDriver driver = new ChromeDriver();

		driver.get("https://www.naukri.com/");

		driver.manage().window().maximize();

		driver.findElement(By.id("login_Layer")).click();

		Thread.sleep(2000);

		driver.findElement(By.xpath("//input[@placeholder='Enter your active Email ID / Username']"))
				.sendKeys("courses4033@gmail.com");

		driver.findElement(By.xpath("//input[@placeholder='Enter your password']")).sendKeys("ammadi@143");

		driver.findElement(By.cssSelector("button[type='submit']")).click();

		Thread.sleep(10000);

		driver.findElement(By.cssSelector("img[alt='naukri user profile img']")).click();

//		driver.findElement(By.linkText("View & Update Profile")).click();

		Thread.sleep(10000);

		driver.findElement(By.xpath("//a[normalize-space()='View & Update Profile']")).click();

		Thread.sleep(10000);

		JavascriptExecutor js = (JavascriptExecutor) driver;

		js.executeScript("window.scrollBy(0,500)");

		Thread.sleep(5000);

		WebElement upload = driver.findElement(By.xpath("//span[@class='dummyUploadNewCTA']"));

		File file = new File(
				"C:\\Users\\fmahammad\\eclipse-workspace\\java-selenium-practice\\src\\main\\resources\\fardeen_resume.pdf");

		Thread.sleep(3000);

		upload.click();

		String filename = file.getAbsolutePath();

		StringSelection filedetails = new StringSelection(filename);
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(filedetails, null);
		Robot robot = new Robot();
		robot.delay(1000);

		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_CONTROL);

		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);

//	      Thread.sleep(3000);

//		driver.findElement(By.xpath("//div[@class='lightbox profileEditDrawer model_open flipOpen']//span[@class='icon'][normalize-space()='CrossLayer']")).click();

	}

}
