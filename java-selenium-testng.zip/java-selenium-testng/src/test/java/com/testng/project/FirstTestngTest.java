package com.testng.project;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Ignore;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class FirstTestngTest {

	

		WebDriver webDriver;

		@BeforeTest
		public void before() {

			// Execute the Code

			// Download the Web Driver Executable
			// Set the Path to Web Driver Executable
			WebDriverManager.chromedriver().setup(); // this one is not necessary

			// Create an instance of WebDriver
			webDriver = new ChromeDriver();

		}

		@Test
		public void testGoogleDotCom() {

//			// Execute the Code
	//
//			// Download the Web Driver Executable
//			// Set the Path to Web Driver Executable
//			WebDriverManager.chromedriver().setup(); // this one is not necessary
//			// Create an instance of WebDriver
//			WebDriver webDriver = new ChromeDriver();

			// WebDriver - Launch up http://www.google.com
			webDriver.get("https://www.google.com");
			webDriver.manage().window().maximize();

//			System.out.println(webDriver.getCurrentUrl());

//			System.out.println(webDriver.getTitle());

			String actualTitle = webDriver.getTitle();
			String expectedTitle = "Google";

			// Check the output
			// WebDriver - Title is Google
			assertEquals(expectedTitle, actualTitle);

//			webDriver.quit();

		}

		@Test
		public void testFacebookDotCom() {

//			// Execute the Code
	//
//			// Download the Web Driver Executable
//			// Set the Path to Web Driver Executable
//			WebDriverManager.chromedriver().setup(); // this one is not necessary
//			// Create an instance of WebDriver
//			WebDriver webDriver = new ChromeDriver();

			// WebDriver - Launch up http://www.facebook.com
			webDriver.get("http://www.facebook.com");
			webDriver.manage().window().maximize();

			System.out.println(webDriver.getCurrentUrl());

			System.out.println(webDriver.getTitle());

			String actualTitle = webDriver.getTitle();
			String expectedTitle = "Facebook – log in or sign up";

			// Check the output
			// WebDriver - Title is Google
			assertEquals(expectedTitle, actualTitle);

//			webDriver.quit();

		}
		
		@AfterTest
		public void after() {
			System.out.println("I'm, Executed");
			webDriver.quit();
		}
		

	}

