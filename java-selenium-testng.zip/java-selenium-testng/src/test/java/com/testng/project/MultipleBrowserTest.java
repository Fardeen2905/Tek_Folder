package com.testng.project;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class MultipleBrowserTest {
//  @Test
//  public void testInFirefox() {
//  }
//  
//  @Test
//  public void testInChrome() {
//  }
//  
//  @Test
//  public void testInIE() {
//	  
//  }
	
	@Parameters("browser")
	@Test
	public void runInBrowser(String browser) {
		
		System.out.println("browser");
	}
}
