package com.example.Spring1;

public class Alien {
	
	public void code() {
		System.out.println("Coding");
	}

}
