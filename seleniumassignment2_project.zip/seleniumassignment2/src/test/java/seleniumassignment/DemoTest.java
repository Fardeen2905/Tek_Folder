package seleniumassignment;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import seleniumassignment.pageobjects.CartPage;
import seleniumassignment.pageobjects.GooglePage;
import seleniumassignment.pageobjects.LandingPage;
import seleniumassignment.pojo.TextData;

public class DemoTest {
	
	private WebDriver driver;
	
	private   TextData textdataobject;
  @Test
  public void loadDataFromText() {
	  
	  GooglePage google = new GooglePage(driver); 
	  
	
	  
		String filePath = "src/main/java/seleniumassignment/pageobjects/demo.txt";
		int i=0;
		
		textdataobject = new TextData();
		

		try {
			BufferedReader reader = new BufferedReader(new FileReader(filePath));
			String key;
			

			while ((key = reader.readLine()) != null) {

				
				if(i==0) {
					textdataobject.setUrl(key);
				}
				else if(i==1) {
					textdataobject.setItem(key);
				}
				i++;

			}

			reader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		google.search(textdataobject.getUrl());
		google.goToHomePage();
		

  }
  
  @BeforeTest
  public void loadDriver()
  {
	  driver = new ChromeDriver();
	  driver.get("https://www.google.com");
	  driver.manage().window().maximize();
  }
  
  @Test(dependsOnMethods="loadDataFromText")
  public void loginCredentials()
  {
	  LandingPage loginpage = new LandingPage(driver);
	  loginpage.enterCredentials("priyankapandrakula@gmail.com", "Priyanka@19");
	  loginpage.submit();
  }
  
  @Test(dependsOnMethods="loadDataFromText")
  public void addToCart()
  {
	  String item = textdataobject.getItem();
	  CartPage cart = new CartPage(driver);
	  cart.addToCart(item);
	  
  }
  
  
  @AfterTest
  public void closeDriver()
  {
	  
  }
}
