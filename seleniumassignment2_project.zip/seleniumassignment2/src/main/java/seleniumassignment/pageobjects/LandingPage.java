package seleniumassignment.pageobjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import seleniumassignment.AbstractComponents.BaseComponent;

public class LandingPage extends BaseComponent{
	
	WebDriver driver;
	
	public LandingPage(WebDriver driver)
	{
		super(driver);
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	
//	WebElement name = driver.findElement(By.name("name"));
	
	//PageFactory
	@FindBy(id="userEmail")
	private WebElement userEmail;
	
	@FindBy(id="userPassword")
	private WebElement passwordEle;
	
	@FindBy(id="login")
	private WebElement submit;
	

	public void enterCredentials(String email, String password)
	{
		userEmail.sendKeys(email);
		passwordEle.sendKeys(password);
		
		
		
	
		
		
		
	}
	
	public void submit()
	{
		submit.click();
	}
	
	
	
	

}
