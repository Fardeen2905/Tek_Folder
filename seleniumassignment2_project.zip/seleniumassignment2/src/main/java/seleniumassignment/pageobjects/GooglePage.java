package seleniumassignment.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class GooglePage {
	
	
		private WebDriver driver;
			
			@FindBy(name="q")
			private WebElement searchBar;
			
			
			public GooglePage(WebDriver driver)
			{
				this.driver=driver;
				PageFactory.initElements(driver,this);
			
			}
			
		    public void search(String key) {
		        searchBar.sendKeys(key);
		        searchBar.submit();
		    }
		    
		    public boolean checkSearchContainsResult(String key)
		    {
		    	WebElement firstSearchResult =  driver.findElement(By.xpath("//a[contains(@href, 'https://rahulshettyacademy.com/client/')]"));
		        String firstSearchResultUrl = firstSearchResult.getAttribute("href");
				return firstSearchResultUrl.contains(key);
		    }
		    
		    public void goToHomePage()
		    {
		    	WebElement firstSearchResult =  driver.findElement(By.xpath("//a[contains(@href, 'https://rahulshettyacademy.com/client/')]"));
		    	firstSearchResult.click();
		    }
		 
		}


